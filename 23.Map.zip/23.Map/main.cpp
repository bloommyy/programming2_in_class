#include <iostream>
#include <map>
using namespace std;

void countries()
{
    double sum=0;
    map <string,double> popul;
    popul["Bulgaria"]=7.128;
    popul["Russia"]=144.3;
    popul["Norway"]=5.233;
    popul["Scotland"]=5.295;
    popul["France"]=66.9;
    map <string,double>::iterator it;
    it=popul.begin();
    for(int i=0; i<5; i++)
    {
        cout<<it->first<<"-"<<it->second<<endl;
        sum=sum+it->second;
        it++;
    }
    cout<<"Population - "<<sum;
}

void singer()
{
    bool flag=false;
    string song1, singer1;
    map <string,string> song;
    do
    {
    cin>>song1;
    if(song1=="0")
    {
        flag=true;
        break;
    }
    cin>>singer1;
    song[song1]=singer1;
    }while(flag!=true);
    map <string,string>::iterator it;
    it=song.begin();
    do
    {
        cout<<it->first<<"-"<<it->second<<endl;
        it++;
    }while(it!=song.end());
}

int main()
{
    countries();
    cout<<endl<<"==================================="<<endl;
    singer();
    return 0;
}
