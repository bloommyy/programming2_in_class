#include <iostream>
#include <cstring>

using namespace std;

string searching(string x, string str[])
{
    string str2;
    bool flag=false;
    for(int i=0; i<5; i++)
    {
        if(x==str[i])
        {
            flag=true;
            break;
        }
    }
    if(flag==1)
    {
        str2="Yes!";
    }else{
        str2="No!";
    }
    return str2;
}
int main()
{
    string x;
    string str[5]={"Random","Nothing","What","Okay","No"};
    cout<<"Enter the word you want to search : ";
    cin>>x;
    cout<<searching(x,str)<<endl;
    string str2[5]={"Idk","Something","Bag","Sink","Ball"};
    cout<<searching(x,str2);
    return 0;
}
