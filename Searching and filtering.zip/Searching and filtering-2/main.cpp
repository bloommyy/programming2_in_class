#include <iostream>

using namespace std;

float filtering(float x, float nums[])
{
    float res=0;
    for(int i=0;i<5;i++)
    {
        if(nums[i]>x)
        {
            res += nums[i];
        }
    }
    return res;
}

int main()
{
    float x, nums[5]{1.53, 2.63, 7.53, 2.45, 5.36};
    cout<<"X = ";
    cin>>x;
    cout<<filtering(x, nums)<<endl;
    float nums2[5]{6.33, 7.13, 8.23, 7.45, 9.36};
    cout<<filtering(x, nums2);
    return 0;
}
